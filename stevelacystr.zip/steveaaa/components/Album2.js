import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function Album2() {
  return (
    <View style={styles.container}>
    <Text style={styles.paragraph}>
        GEMINI RIGHTS:
      </Text>
      <Image style={styles.logo} source={require('../assets/stevealbun.jpg')} /> 
      <Button
        title="LISTEN NOW"
        onPress={() => Alert.alert('Simple Button pressed')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ff6400',
    padding: 24,
  },
  logo: {
    height: 128,
    width: 128,
  },
  paragraph: {
    margin: 15,
    fontSize: 13,
    color: "#FFF",
    fontWeight: 'bold',
    textAlign: 'center',
  },
});