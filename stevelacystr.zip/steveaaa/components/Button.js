import { View, StyleSheet, Button, Alert, } from 'react-native';

export default function Button(): {
  return (
    <SafeAreaView>
     <Button
        title="PLAY NOW"
        onPress={() => Alert.alert('Simple Button pressed')}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 5,
    justifyContent: 'center',
    marginHorizontal: 10,
  },
});